require('dotenv').config();
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const { google } = require('googleapis');
const Anthropic = require('@anthropic-ai/sdk');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Anthropic client ──────────────────────────────────────────────
const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── Google OAuth client ───────────────────────────────────────────
function getOAuthClient() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}

// ── Middleware ────────────────────────────────────────────────────
app.use(express.json());
app.use(cors({
  origin: process.env.FRONTEND_URL || 'https://friendly-klepon-b00b06.netlify.app',
  credentials: true
}));
app.use(session({
  secret: process.env.SESSION_SECRET || 'change-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    sameSite: process.env.NODE_ENV === 'production' ? 'none' : 'lax'
  }
}));

// ── Auth middleware ───────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (!req.session.tokens) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  next();
}

// ── Routes ────────────────────────────────────────────────────────

// Health check
app.get('/', (req, res) => res.json({ status: 'Gmail Cleaner API running' }));

// Start Google OAuth flow
app.get('/auth/google', (req, res) => {
  const oauth2Client = getOAuthClient();
  const url = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: [
      'https://www.googleapis.com/auth/gmail.readonly',
      'https://www.googleapis.com/auth/gmail.modify',
      'https://www.googleapis.com/auth/userinfo.email',
      'https://www.googleapis.com/auth/userinfo.profile'
    ]
  });
  res.redirect(url);
});

// Google OAuth callback
app.get('/auth/google/callback', async (req, res) => {
  const { code, error } = req.query;

  if (error) {
    return res.redirect(`${process.env.FRONTEND_URL}?error=auth_denied`);
  }

  try {
    const oauth2Client = getOAuthClient();
    const { tokens } = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(tokens);

    // Get user info
    const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
    const { data: userInfo } = await oauth2.userinfo.get();

    req.session.tokens = tokens;
    req.session.user = {
      email: userInfo.email,
      name: userInfo.name,
      picture: userInfo.picture
    };

    res.redirect(`${process.env.FRONTEND_URL}?auth=success`);
  } catch (err) {
    console.error('OAuth callback error:', err);
    res.redirect(`${process.env.FRONTEND_URL}?error=auth_failed`);
  }
});

// Get current user
app.get('/auth/me', requireAuth, (req, res) => {
  res.json({ user: req.session.user });
});

// Logout
app.post('/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

// Fetch emails
app.get('/emails', requireAuth, async (req, res) => {
  try {
    const oauth2Client = getOAuthClient();
    oauth2Client.setCredentials(req.session.tokens);

    const gmail = google.gmail({ version: 'v1', auth: oauth2Client });
    const { maxResults = 50 } = req.query;

    // Fetch message list
    const listRes = await gmail.users.messages.list({
      userId: 'me',
      maxResults: parseInt(maxResults),
      q: 'in:inbox'
    });

    const messages = listRes.data.messages || [];

    // Fetch each message's details
    const emailDetails = await Promise.all(
      messages.map(async (msg) => {
        const detail = await gmail.users.messages.get({
          userId: 'me',
          id: msg.id,
          format: 'metadata',
          metadataHeaders: ['Subject', 'From', 'Date']
        });

        const headers = detail.data.payload.headers;
        const getHeader = (name) =>
          headers.find(h => h.name.toLowerCase() === name.toLowerCase())?.value || '';

        return {
          id: msg.id,
          subject: getHeader('Subject') || '(no subject)',
          from: getHeader('From'),
          date: getHeader('Date'),
          snippet: detail.data.snippet || ''
        };
      })
    );

    res.json({ emails: emailDetails });
  } catch (err) {
    console.error('Email fetch error:', err);
    res.status(500).json({ error: 'Failed to fetch emails' });
  }
});

// Classify emails with Claude
app.post('/classify', requireAuth, async (req, res) => {
  const { emails } = req.body;

  if (!emails || !Array.isArray(emails)) {
    return res.status(400).json({ error: 'emails array required' });
  }

  try {
    const emailList = emails.map((e, i) =>
      `${i + 1}. ID: ${e.id}\n   From: ${e.from}\n   Subject: ${e.subject}\n   Preview: ${e.snippet}`
    ).join('\n\n');

    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      messages: [{
        role: 'user',
        content: `Classify these emails. For each one respond ONLY with valid JSON array.

Classify each as:
- "spam": obvious spam, scam, or junk
- "promo": marketing, newsletters, promotions, deals
- "safe": important emails I should keep (personal, work, receipts, etc.)

Emails:
${emailList}

Respond ONLY with a JSON array like:
[{"id":"...","category":"spam","reason":"..."},...]
No extra text, no markdown.`
      }]
    });

    const raw = message.content[0].text.trim();
    const cleaned = raw.replace(/```json|```/g, '').trim();
    const results = JSON.parse(cleaned);

    res.json({ results });
  } catch (err) {
    console.error('Classification error:', err);
    res.status(500).json({ error: 'Classification failed' });
  }
});

// Delete emails
app.post('/delete', requireAuth, async (req, res) => {
  const { emailIds } = req.body;

  if (!emailIds || !Array.isArray(emailIds)) {
    return res.status(400).json({ error: 'emailIds array required' });
  }

  try {
    const oauth2Client = getOAuthClient();
    oauth2Client.setCredentials(req.session.tokens);
    const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

    // Move to trash (safer than permanent delete)
    await Promise.all(
      emailIds.map(id =>
        gmail.users.messages.trash({ userId: 'me', id })
      )
    );

    res.json({ success: true, deleted: emailIds.length });
  } catch (err) {
    console.error('Delete error:', err);
    res.status(500).json({ error: 'Failed to delete emails' });
  }
});

// ── Start server ──────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
