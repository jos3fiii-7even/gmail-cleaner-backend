# Gmail Cleaner — Backend

Node.js backend for the Gmail Cleaner app. Handles Google OAuth and Claude AI classification server-side.

## Deploy to Railway

1. Push this folder to a GitHub repo
2. In Railway: New Project → Deploy from GitHub repo → select this repo
3. Add these environment variables in Railway dashboard:

```
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-secret
GOOGLE_REDIRECT_URI=https://YOUR-APP.up.railway.app/auth/google/callback
FRONTEND_URL=https://friendly-klepon-b00b06.netlify.app
SESSION_SECRET=any-long-random-string-here
NODE_ENV=production
```

4. After deploy, copy your Railway URL (e.g. https://gmail-cleaner-production.up.railway.app)
5. Update GOOGLE_REDIRECT_URI in Railway env vars to use that URL
6. Add that URL to Google Cloud Console → OAuth → Authorized Redirect URIs
7. Update the `API` constant in frontend/index.html with your Railway URL
8. Redeploy frontend/index.html to Netlify
